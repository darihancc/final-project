package com.example.hli3584.weatherapp.Model;

public class Clouds {
    private int all;

    public Clouds() {
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
