package com.example.hli3584.weatherapp.Model;

public class Rain {
}
